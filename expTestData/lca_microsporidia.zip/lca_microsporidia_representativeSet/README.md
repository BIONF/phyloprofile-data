# Test Data for [PhyloProfile Tool](https://github.com/BIONF/PhyloProfile)

This folder contains LCA Microsporidia phylogenetic profile data used for testing [the performance of PhyloProfile](https://github.com/BIONF/PhyloProfile/wiki/Performance-test).

Main input file is *lca.list.distribution*.

Domain files are saved in *domain_files* folder.

Fasta files for this data are not provided.
